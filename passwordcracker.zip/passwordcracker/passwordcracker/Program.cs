﻿using System;
using System.Diagnostics;

class PasswordCracker
{
    static void Main(string[] args)
    {
        string[] Zeichen = { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z","a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z" };

        string richtiges_passwort = "00001808"; 

        bool pf = false;
        int passwortCount = 0;
        Stopwatch stopwatch = new Stopwatch();
        stopwatch.Start();
        while (!pf)
        {
            for (int i = 0; i < Zeichen.Length && !pf; i++)
            {
                for (int j = 0; j < Zeichen.Length && !pf; j++)
                {
                    for (int k = 0; k < Zeichen.Length && !pf; k++)
                    {
                        for (int l = 0; l < Zeichen.Length && !pf; l++)
                        {
                            for (int m = 0; m < Zeichen.Length && !pf; m++)
                            {
                                for (int n = 0; n < Zeichen.Length && !pf; n++)
                                {
                                    for (int o = 0; o < Zeichen.Length && !pf; o++)
                                    {
                                        for (int p = 0; p < Zeichen.Length && !pf; p++)
                                        {
                                            passwortCount++;
                                            Console.WriteLine("Versuche: " + passwortCount);
                                            string password = Zeichen[i] + Zeichen[j] + Zeichen[k] + Zeichen[l] + Zeichen[m] + Zeichen[n] + Zeichen[o] + Zeichen[p];
                                            Console.WriteLine("probiertes Passwort: " + password);
                                            if (password == richtiges_passwort)
                                            {
                                                Console.WriteLine("Das Passwort ist: " + password);
                                                pf = true;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        stopwatch.Stop();
        Console.WriteLine("Zeit gebraucht: "+ stopwatch.Elapsed.ToString());
        Console.WriteLine("Versuche gebraucht: " + passwortCount );

    }
}
